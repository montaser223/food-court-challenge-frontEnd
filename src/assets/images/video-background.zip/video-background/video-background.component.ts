import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-background',
  templateUrl: './video-background.component.html',
  styleUrls: ['./video-background.component.css']
})
export class VideoBackgroundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
